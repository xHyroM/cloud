const express = require("express");
const app = express();
const fs = require("fs");
const path = require("path");
var caps = new Map();
var tabs = new Map();
var clients = new Map();

var allplayers = [];
var finalp = "";

allplayers.forEach(f => {
  finalp = `${finalp} ${f}`
})


app.get("/capes/:id", async(req, res) => {
  if(caps.get(req.params.id) != null){
    res.sendFile(path.resolve(`capes/${caps.get(req.params.id)}`));
    console.log("");
  } else if(req.params.id == "players") {
    res.send(finalp)
    console.log(finalp)
  } else res.status(404).send("idiote")
})

app.get("/tab/:id", async(req, res) => {
  if(tabs.get(req.params.id) != null){
    res.send(tabs.get(req.params.id));
  } else if(req.params.id == "players") {
    res.send(finalp)
    console.log(finalp)
  } else res.status(404).send("idiote")
})


app.get(`/add/${process.env.pass}/`, async(req,res) => {
  var username = req.query.name
  var clientname = req.query.clientname

  if(!username) return res.send("strč sa ty kokot");
  if(!clientname) return res.send("neskúšaj idiot");
  
  console.log(username);
  
  if(clients.get(clientname) != null){
    
    caps.set(username, clients.get(clientname).split(">")[0]);
    tabs.set(username, clients.get(clientname).split(">")[1]);
    console.log("CAPE: " + clients.get(clientname).split(">")[0]);
    console.log("tabs: " + clients.get(clientname).split(">")[1]);
    allplayers.push(username);

    if(finalp.includes(username)) {} else finalp = finalp + " "+username 
    res.status(200).send("yes")
  } else return res.status(404).send("lol");
})

app.listen(3000, () => {
  //register clients  
  clients.set("darklight", "darklight.png>§8[§0D§fL§8]§r");
  clients.set("invalid","mojang.png>§8[§cInvalid§8]§r")
  clients.set("moclient","minecon2013.png>§8[§aMoClient§8]§r")
});